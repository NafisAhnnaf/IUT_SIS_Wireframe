import React, { useState } from "react";

type Screen = "dashboard" | "profile" | "feedback" | "result" | "admit-card" | "library" | "change-password";

// ─── Data ──────────────────────────────────────────────────────────────────────

const STUDENT = {
  id: "230042150",
  name: "Nafis Ahnaf Jamil",
  dept: "Computer Science & Engineering",
  program: "B.Sc. in Software Engineering",
  batch: "2023",
  ay: "2024–2025",
  semester: "Summer Semester",
  semNum: 4,
  cgpa: "3.72",
  totalCredits: 42,
  email: "nafis.230042150@iut-dhaka.edu",
  phone: "+880 1712-345678",
  gender: "Male",
  dob: "12 March 2003",
  blood: "B+",
  address: "House 12, Road 5, Dhanmondi, Dhaka-1209",
  emergAddr: "House 12, Road 5, Dhanmondi, Dhaka-1209",
  country: "Bangladesh",
  fatherName: "Jamil Ahmed",
  fatherProf: "Businessman",
  motherName: "Nusrat Jamil",
  motherProf: "Homemaker",
  guardianName: "Jamil Ahmed",
  guardianPhone: "+880 1812-345678",
};

const SEMESTERS = [
  {
    id: 4, label: "Semester 4", period: "Summer 2024", gpa: "3.85",
    courses: [
      { code: "CSE 4403", title: "Algorithms", cr: 3.0, grade: "A", pts: 4.0 },
      { code: "CSE 4404", title: "Algorithms Lab", cr: 1.5, grade: "A", pts: 4.0 },
      { code: "CSE 4409", title: "Database Management Systems II", cr: 3.0, grade: "A-", pts: 3.7 },
      { code: "CSE 4410", title: "DBMS II Lab", cr: 1.5, grade: "A", pts: 4.0 },
      { code: "CSE 4411", title: "Data Communication and Networking", cr: 3.0, grade: "B+", pts: 3.3 },
      { code: "HUM 4441", title: "Engineering Ethics", cr: 2.0, grade: "A", pts: 4.0 },
    ],
  },
  {
    id: 3, label: "Semester 3", period: "Spring 2024", gpa: "3.65",
    courses: [
      { code: "CSE 3301", title: "Operating Systems", cr: 3.0, grade: "A-", pts: 3.7 },
      { code: "CSE 3302", title: "Operating Systems Lab", cr: 1.5, grade: "A", pts: 4.0 },
      { code: "CSE 3303", title: "Computer Architecture", cr: 3.0, grade: "B+", pts: 3.3 },
      { code: "MATH 3301", title: "Discrete Mathematics", cr: 3.0, grade: "A-", pts: 3.7 },
      { code: "CSE 3305", title: "Software Engineering", cr: 3.0, grade: "A", pts: 4.0 },
    ],
  },
  {
    id: 2, label: "Semester 2", period: "Fall 2023", gpa: "3.60",
    courses: [
      { code: "CSE 2201", title: "Data Structures", cr: 3.0, grade: "A-", pts: 3.7 },
      { code: "CSE 2202", title: "Data Structures Lab", cr: 1.5, grade: "A", pts: 4.0 },
      { code: "CSE 2203", title: "Digital Logic Design", cr: 3.0, grade: "B+", pts: 3.3 },
      { code: "MATH 2201", title: "Calculus II", cr: 3.0, grade: "A", pts: 4.0 },
      { code: "PHY 2201", title: "Physics I", cr: 3.0, grade: "B+", pts: 3.3 },
    ],
  },
  {
    id: 1, label: "Semester 1", period: "Summer 2023", gpa: "3.55",
    courses: [
      { code: "CSE 1101", title: "Programming Fundamentals", cr: 3.0, grade: "A", pts: 4.0 },
      { code: "CSE 1102", title: "Programming Fundamentals Lab", cr: 1.5, grade: "A", pts: 4.0 },
      { code: "MATH 1101", title: "Calculus I", cr: 3.0, grade: "A-", pts: 3.7 },
      { code: "PHY 1101", title: "Physics I", cr: 3.0, grade: "B+", pts: 3.3 },
      { code: "HUM 1101", title: "English Communication", cr: 2.0, grade: "A", pts: 4.0 },
    ],
  },
];

const FEEDBACK_INIT = [
  { code: "CSE 4403", title: "Algorithms", teacher: "Anika Farzana", status: "Evaluated" },
  { code: "CSE 4404", title: "Algorithms Lab", teacher: "Anika Farzana", status: "Evaluated" },
  { code: "CSE 4404", title: "Algorithms Lab", teacher: "Sabrina Islam", status: "Evaluated" },
  { code: "CSE 4409", title: "Database Management Systems II", teacher: "Dr. Abu Raihan Mostofa Kamal", status: "Evaluated" },
  { code: "CSE 4410", title: "DBMS II Lab", teacher: "A N M Zahid Hossain Milkan", status: "Evaluated" },
  { code: "CSE 4410", title: "DBMS II Lab", teacher: "Sumit Alam Khan", status: "Pending" },
  { code: "CSE 4411", title: "Data Communication and Networking", teacher: "Faisal Hussain", status: "Pending" },
  { code: "CSE 4412", title: "DCN Lab", teacher: "Faisal Hussain", status: "Pending" },
  { code: "HUM 4441", title: "Engineering Ethics", teacher: "Yousuf Ibne Kamal Niloy", status: "Evaluated" },
  { code: "MATH 4441", title: "Probability and Statistics", teacher: "Dr. Muntasir Alam", status: "Evaluated" },
  { code: "SWE 4401", title: "Software Requirements and Specifications", teacher: "Farzana Tabassum", status: "Evaluated" },
  { code: "SWE 4402", title: "SRS Lab", teacher: "Sohel Ahmed", status: "Evaluated" },
];

const EXAMS = [
  { date: "15 Dec 2024", day: "Sun", time: "9:00 AM", code: "CSE 4403", title: "Algorithms", room: "E-301", duration: "3h" },
  { date: "17 Dec 2024", day: "Tue", time: "9:00 AM", code: "CSE 4409", title: "Database Management Systems II", room: "E-302", duration: "3h" },
  { date: "19 Dec 2024", day: "Thu", time: "9:00 AM", code: "CSE 4411", title: "Data Communication and Networking", room: "E-303", duration: "3h" },
  { date: "21 Dec 2024", day: "Sat", time: "9:00 AM", code: "HUM 4441", title: "Engineering Ethics", room: "C-101", duration: "2h" },
  { date: "23 Dec 2024", day: "Mon", time: "9:00 AM", code: "MATH 4441", title: "Probability and Statistics", room: "C-201", duration: "3h" },
  { date: "26 Dec 2024", day: "Thu", time: "9:00 AM", code: "SWE 4401", title: "Software Requirements and Specifications", room: "E-304", duration: "3h" },
];

const LIBRARY_CURRENT = [
  {
    id: "LIB-2024-0847",
    title: "Introduction to Algorithms",
    author: "Cormen, Leiserson, Rivest & Stein",
    isbn: "978-0-262-03384-8",
    category: "Computer Science",
    issued: "01 Nov 2024",
    due: "15 Dec 2024",
    daysLeft: 3,
  },
  {
    id: "LIB-2024-0612",
    title: "Clean Code",
    author: "Robert C. Martin",
    isbn: "978-0-13-235088-4",
    category: "Software Engineering",
    issued: "10 Nov 2024",
    due: "25 Nov 2024",
    daysLeft: -20,
  },
  {
    id: "LIB-2024-0931",
    title: "Design Patterns",
    author: "Gamma, Helm, Johnson & Vlissides",
    isbn: "978-0-201-63361-0",
    category: "Software Engineering",
    issued: "20 Nov 2024",
    due: "04 Jan 2025",
    daysLeft: 25,
  },
];

const LIBRARY_HISTORY = [
  {
    title: "The Pragmatic Programmer",
    author: "David Thomas & Andrew Hunt",
    isbn: "978-0-13-595705-9",
    category: "Software Engineering",
    issued: "12 Sep 2024",
    returned: "10 Oct 2024",
    status: "On Time",
  },
  {
    title: "Computer Networks",
    author: "Andrew S. Tanenbaum",
    isbn: "978-0-13-212695-3",
    category: "Networking",
    issued: "01 Aug 2024",
    returned: "05 Sep 2024",
    status: "On Time",
  },
  {
    title: "Operating System Concepts",
    author: "Silberschatz, Galvin & Gagne",
    isbn: "978-1-119-32091-3",
    category: "Systems",
    issued: "15 Jun 2024",
    returned: "20 Aug 2024",
    status: "Late",
  },
  {
    title: "Calculus: Early Transcendentals",
    author: "James Stewart",
    isbn: "978-1-285-74155-0",
    category: "Mathematics",
    issued: "10 May 2024",
    returned: "30 Jul 2024",
    status: "On Time",
  },
];

// ─── Icons ────────────────────────────────────────────────────────────────────

function IcoDashboard() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" />
      <rect x="14" y="14" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" />
    </svg>
  );
}
function IcoProfile() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="8" r="4" /><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" />
    </svg>
  );
}
function IcoFeedback() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
    </svg>
  );
}
function IcoResult() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 11l3 3L22 4" /><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
    </svg>
  );
}
function IcoCard() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="5" width="20" height="14" rx="2" /><line x1="2" y1="10" x2="22" y2="10" />
    </svg>
  );
}
function IcoBook() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
    </svg>
  );
}
function IcoLock() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
  );
}
function IcoChevronRight() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 18l6-6-6-6" />
    </svg>
  );
}
function IcoChevronDown({ open }: { open: boolean }) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"
      style={{ transform: open ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s ease" }}>
      <path d="M6 9l6 6 6-6" />
    </svg>
  );
}
function IcoMenu() {
  return (
    <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="18" x2="21" y2="18" />
    </svg>
  );
}
function IcoClose() {
  return (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
}
function IcoEdit() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
    </svg>
  );
}
function IcoDownload() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
    </svg>
  );
}
function IcoEye({ visible }: { visible: boolean }) {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      {visible
        ? <><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" /><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" /><line x1="1" y1="1" x2="23" y2="23" /></>
        : <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></>
      }
    </svg>
  );
}
function IcoStar({ filled }: { filled: boolean }) {
  return (
    <svg width="26" height="26" viewBox="0 0 24 24" fill={filled ? "#F59E0B" : "none"} stroke={filled ? "#F59E0B" : "#CBD5E1"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
  );
}
function IcoClock() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
    </svg>
  );
}

// ─── Nav Config ───────────────────────────────────────────────────────────────

const NAV: { id: Screen; label: string; icon: React.ReactNode }[] = [
  { id: "dashboard", label: "Dashboard", icon: <IcoDashboard /> },
  { id: "profile", label: "Profile", icon: <IcoProfile /> },
  { id: "feedback", label: "Course Feedback", icon: <IcoFeedback /> },
  { id: "result", label: "Result", icon: <IcoResult /> },
  { id: "admit-card", label: "Exam Admit Card", icon: <IcoCard /> },
  { id: "library", label: "Library", icon: <IcoBook /> },
  { id: "change-password", label: "Change Password", icon: <IcoLock /> },
];

const PAGE_LABELS: Record<Screen, string> = {
  dashboard: "Dashboard",
  profile: "Profile",
  feedback: "Course Feedback",
  result: "View Result",
  "admit-card": "Exam Admit Card",
  library: "Library",
  "change-password": "Change Password",
};

// ─── Shared Components ────────────────────────────────────────────────────────

function InitialsAvatar({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const cls = {
    sm: "w-8 h-8 text-xs",
    md: "w-10 h-10 text-sm",
    lg: "w-20 h-20 text-xl",
  }[size];
  return (
    <div className={`${cls} rounded-full bg-gradient-to-br from-[#1E3A8A] to-[#3B5FBD] text-white flex items-center justify-center font-bold shrink-0 tracking-wide shadow-md`}>
      NA
    </div>
  );
}

function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-white/75 backdrop-blur-md rounded-2xl border border-white/60 shadow-sm ${className}`}>
      {children}
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-[10px] font-bold text-[#94A3B8] uppercase tracking-[0.1em]">{children}</p>
  );
}

function StatCard({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="bg-white/70 backdrop-blur-md rounded-2xl border border-white/60 shadow-sm p-5">
      <SectionLabel>{label}</SectionLabel>
      <p className="text-[2rem] font-extrabold leading-none text-[#0F172A] mt-2 tracking-tight">{value}</p>
      {sub && <p className="text-xs text-[#94A3B8] mt-1.5 font-medium">{sub}</p>}
    </div>
  );
}

function StudentBanner() {
  return (
    <Card className="p-5 flex items-center gap-4 mb-5">
      <InitialsAvatar size="md" />
      <div className="flex-1 min-w-0">
        <p className="font-bold text-[#0F172A] text-base leading-tight">{STUDENT.name}</p>
        <p className="text-[#64748B] text-xs mt-0.5">{STUDENT.dept}</p>
      </div>
      <div className="hidden sm:flex flex-col items-end gap-0.5 shrink-0">
        <span className="text-[11px] text-[#94A3B8] font-medium">Student ID</span>
        <span className="font-mono font-bold text-[#1E3A8A] text-sm">{STUDENT.id}</span>
        <span className="text-[11px] text-[#94A3B8] mt-1 font-medium">{STUDENT.ay} · Sem {STUDENT.semNum}</span>
      </div>
    </Card>
  );
}

function PageHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-6">
      <h1 className="font-extrabold text-2xl md:text-[1.875rem] text-[#0F172A] leading-tight tracking-tight">{title}</h1>
      {subtitle && <p className="text-sm text-[#94A3B8] mt-1 font-medium">{subtitle}</p>}
    </div>
  );
}

function gradeChip(grade: string) {
  if (grade.startsWith("A")) return "bg-emerald-50 text-emerald-700 border border-emerald-200";
  if (grade.startsWith("B")) return "bg-blue-50 text-blue-700 border border-blue-200";
  if (grade.startsWith("C")) return "bg-amber-50 text-amber-700 border border-amber-200";
  return "bg-red-50 text-red-700 border border-red-200";
}

function loanStatus(daysLeft: number) {
  if (daysLeft < 0) return { label: `${Math.abs(daysLeft)}d overdue`, cls: "bg-red-50 text-red-700 border border-red-200", dot: "bg-red-500" };
  if (daysLeft <= 7) return { label: `Due in ${daysLeft}d`, cls: "bg-amber-50 text-amber-700 border border-amber-200", dot: "bg-amber-500" };
  return { label: `${daysLeft}d remaining`, cls: "bg-emerald-50 text-emerald-700 border border-emerald-200", dot: "bg-emerald-500" };
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────

function Sidebar({ screen, onNav, onClose }: { screen: Screen; onNav: (s: Screen) => void; onClose?: () => void }) {
  return (
    <aside className="w-64 h-full bg-[#0B1628]/92 backdrop-blur-xl flex flex-col border-r border-white/[0.08]">
      {/* Logo + optional close */}
      <div className="px-5 py-5 border-b border-white/[0.08] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#1E3A8A] to-[#3B5FBD] flex items-center justify-center shrink-0 shadow-lg">
            <span className="text-white font-extrabold text-xs tracking-tight">IUT</span>
          </div>
          <div>
            <p className="text-white text-sm font-bold leading-none">Student Portal</p>
            <p className="text-white/35 text-[10px] mt-0.5 leading-none font-medium">Islamic Univ. of Technology</p>
          </div>
        </div>
        {onClose && (
          <button onClick={onClose} className="text-white/40 hover:text-white transition-colors ml-2 shrink-0">
            <IcoClose />
          </button>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {NAV.map((item) => {
          const active = screen === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNav(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] font-semibold transition-all duration-150 text-left ${
                active
                  ? "bg-white/[0.12] text-white border border-white/[0.12] shadow-sm"
                  : "text-white/45 hover:text-white hover:bg-white/[0.07]"
              }`}
            >
              {active && <span className="w-0.5 h-4 rounded-full bg-[#60A5FA] absolute left-3 shrink-0" />}
              <span className={active ? "text-white" : "text-white/40"}>{item.icon}</span>
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Bottom accent */}
      <div className="px-5 py-4 border-t border-white/[0.08]">
        <p className="text-white/20 text-[10px] font-medium">2026 &copy; IUT Student Information System</p>
      </div>
    </aside>
  );
}

// ─── Top Bar ──────────────────────────────────────────────────────────────────

function TopBar({ screen, onMenuClick }: { screen: Screen; onMenuClick: () => void }) {
  return (
    <header className="h-14 bg-white/65 backdrop-blur-lg border-b border-white/50 flex items-center px-4 md:px-6 shrink-0 z-10">
      <button className="md:hidden mr-3 text-[#64748B] hover:text-[#0F172A] transition-colors" onClick={onMenuClick}>
        <IcoMenu />
      </button>

      <div className="md:hidden flex items-center gap-2 mr-auto">
        <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#1E3A8A] to-[#3B5FBD] flex items-center justify-center shadow-sm">
          <span className="text-white font-extrabold text-[10px]">IUT</span>
        </div>
        <span className="text-[#0F172A] font-bold text-sm">Student Portal</span>
      </div>

      <div className="hidden md:flex items-center gap-2 text-sm">
        <span className="text-[#94A3B8] font-medium">SIS</span>
        <span className="text-[#CBD5E1]">/</span>
        <span className="text-[#0F172A] font-bold">{PAGE_LABELS[screen]}</span>
      </div>

      <div className="ml-auto flex items-center gap-3">
        <div className="hidden md:block text-right">
          <p className="text-[#0F172A] text-sm font-bold leading-none">{STUDENT.name}</p>
          <p className="text-[#94A3B8] text-[11px] mt-0.5 font-medium">{STUDENT.id}</p>
        </div>
        <InitialsAvatar size="sm" />
      </div>
    </header>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

function DashboardScreen({ onNav }: { onNav: (s: Screen) => void }) {
  return (
    <div className="p-4 md:p-8 max-w-5xl">
      <PageHeader
        title={`Good morning, Nafis.`}
        subtitle={`${STUDENT.ay} · ${STUDENT.semester} · Semester ${STUDENT.semNum}`}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <StatCard label="Academic Year" value={STUDENT.ay} />
        <StatCard label="Current Semester" value={`Sem ${STUDENT.semNum}`} sub={STUDENT.semester} />
        <StatCard label="CGPA" value={STUDENT.cgpa} sub="out of 4.00" />
        <StatCard label="Credits Earned" value={String(STUDENT.totalCredits)} sub="total completed" />
      </div>

      {/* Identity card */}
      <Card className="p-5 flex items-center gap-5 mb-5">
        <InitialsAvatar size="lg" />
        <div className="flex-1 min-w-0">
          <p className="font-extrabold text-xl text-[#0F172A] tracking-tight">{STUDENT.name}</p>
          <p className="text-[#64748B] text-sm mt-0.5 font-medium">{STUDENT.dept}</p>
          <p className="text-[#94A3B8] text-xs mt-1 font-medium">
            {STUDENT.program} · Batch {STUDENT.batch}
          </p>
          <p className="text-[#94A3B8] text-xs mt-0.5">
            ID&nbsp;<span className="font-mono font-bold text-[#1E3A8A]">{STUDENT.id}</span>
          </p>
        </div>
        <div className="hidden sm:block shrink-0">
          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            Active
          </span>
        </div>
      </Card>

      <h2 className="font-bold text-lg text-[#0F172A] mb-3 tracking-tight">Quick Access</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-5">
        {[
          { screen: "result" as Screen, label: "View Results", desc: `CGPA ${STUDENT.cgpa} · ${STUDENT.semNum} semesters completed`, accent: "from-blue-50/80 to-indigo-50/60 border-blue-200/60", arrow: "text-[#1E3A8A]" },
          { screen: "feedback" as Screen, label: "Course Feedback", desc: "3 evaluations pending · Submit before deadline", accent: "from-amber-50/80 to-orange-50/60 border-amber-200/60", arrow: "text-amber-600" },
          { screen: "library" as Screen, label: "Library", desc: "1 book overdue · Return before next visit", accent: "from-red-50/80 to-rose-50/60 border-red-200/60", arrow: "text-red-600" },
        ].map((q) => (
          <button
            key={q.screen}
            onClick={() => onNav(q.screen)}
            className={`text-left p-5 rounded-2xl border bg-gradient-to-br ${q.accent} backdrop-blur-sm hover:shadow-md transition-all duration-200 group`}
          >
            <div className="flex items-start justify-between mb-2">
              <span className="font-bold text-sm text-[#0F172A]">{q.label}</span>
              <span className={`${q.arrow} opacity-60 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all`}>
                <IcoChevronRight />
              </span>
            </div>
            <p className="text-[#64748B] text-xs leading-relaxed font-medium">{q.desc}</p>
          </button>
        ))}
      </div>

      <div className="flex gap-4 p-4 rounded-2xl bg-white/50 backdrop-blur-sm border border-white/50">
        <div className="w-0.5 rounded-full bg-gradient-to-b from-[#1E3A8A] to-[#3B5FBD] shrink-0" />
        <div>
          <p className="text-xs font-bold text-[#0F172A]">Academic Notice</p>
          <p className="text-xs text-[#64748B] mt-0.5 leading-relaxed font-medium">
            Final examinations begin 15 December 2024. Ensure your admit card is downloaded
            and verified before your first exam.
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── Profile ──────────────────────────────────────────────────────────────────

function ProfileScreen() {
  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({
    phone: STUDENT.phone,
    email: STUDENT.email,
    address: STUDENT.address,
    emergAddr: STUDENT.emergAddr,
    blood: STUDENT.blood,
  });

  function handleSave() {
    setEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  function handleCancel() {
    setForm({ phone: STUDENT.phone, email: STUDENT.email, address: STUDENT.address, emergAddr: STUDENT.emergAddr, blood: STUDENT.blood });
    setEditing(false);
  }

  const fieldClass = "w-full text-sm text-[#0F172A] font-medium bg-white/60 backdrop-blur-sm border border-white/60 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-[#1E3A8A] focus:bg-white/80 focus:ring-2 focus:ring-[#1E3A8A]/10 transition";

  return (
    <div className="p-4 md:p-8 max-w-4xl">
      <div className="flex items-start justify-between mb-6">
        <PageHeader title="My Profile" subtitle="Manage your personal and contact information" />
        {!editing && (
          <button onClick={() => setEditing(true)} className="flex items-center gap-1.5 px-4 py-2 text-sm font-bold text-[#1E3A8A] border border-[#BFDBFE] rounded-xl hover:bg-[#EFF6FF] transition-colors bg-white/60 backdrop-blur-sm">
            <IcoEdit /> Edit Profile
          </button>
        )}
      </div>

      {saved && (
        <div className="mb-4 px-4 py-3 rounded-xl bg-emerald-50/80 backdrop-blur-sm border border-emerald-200 text-emerald-700 text-sm font-semibold">
          Profile updated successfully.
        </div>
      )}

      <Card className="p-6 flex items-center gap-5 mb-4">
        <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#1E3A8A] to-[#3B5FBD] text-white flex items-center justify-center font-extrabold text-2xl shrink-0 shadow-lg">
          NA
        </div>
        <div>
          <p className="font-extrabold text-2xl text-[#0F172A] tracking-tight">{STUDENT.name}</p>
          <p className="text-[#64748B] text-sm mt-0.5 font-medium">{STUDENT.dept}</p>
          <p className="text-[#94A3B8] text-xs mt-1 font-medium">{STUDENT.program} · Batch {STUDENT.batch}</p>
        </div>
      </Card>

      <Card className="mb-4 overflow-hidden">
        <div className="px-5 py-4 border-b border-white/40">
          <SectionLabel>Academic Information</SectionLabel>
        </div>
        <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-5">
          {[
            { label: "Student ID", value: STUDENT.id },
            { label: "Academic Year", value: STUDENT.ay },
            { label: "Department", value: STUDENT.dept },
            { label: "Current Semester", value: `Semester ${STUDENT.semNum} (${STUDENT.semester})` },
            { label: "Program", value: STUDENT.program },
            { label: "Batch", value: STUDENT.batch },
          ].map(({ label, value }) => (
            <div key={label}>
              <p className="text-[11px] text-[#94A3B8] mb-0.5 font-semibold">{label}</p>
              <p className="text-sm font-semibold text-[#0F172A]">{value}</p>
            </div>
          ))}
        </div>
        <div className="px-5 pb-4">
          <p className="text-[11px] text-[#94A3B8] italic font-medium">
            For academic record updates, please contact the Registrar Office.
          </p>
        </div>
      </Card>

      <Card className="mb-4 overflow-hidden">
        <div className="px-5 py-4 border-b border-white/40">
          <SectionLabel>Personal Information</SectionLabel>
        </div>
        <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-5">
          {[
            { label: "Date of Birth", value: STUDENT.dob },
            { label: "Gender", value: STUDENT.gender },
            { label: "Country", value: STUDENT.country },
          ].map(({ label, value }) => (
            <div key={label}>
              <p className="text-[11px] text-[#94A3B8] mb-0.5 font-semibold">{label}</p>
              <p className="text-sm font-semibold text-[#0F172A]">{value}</p>
            </div>
          ))}

          {(["blood", "phone", "email"] as const).map((key) => {
            const labels: Record<string, string> = { blood: "Blood Group", phone: "Phone", email: "University Email" };
            return (
              <div key={key}>
                <p className="text-[11px] text-[#94A3B8] mb-1 font-semibold">{labels[key]}</p>
                {editing ? (
                  <input type="text" value={form[key]} onChange={(e) => setForm({ ...form, [key]: e.target.value })} className={fieldClass} />
                ) : (
                  <p className="text-sm font-semibold text-[#0F172A]">{form[key]}</p>
                )}
              </div>
            );
          })}

          <div className="sm:col-span-2">
            <p className="text-[11px] text-[#94A3B8] mb-1 font-semibold">Present Address</p>
            {editing ? (
              <textarea value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} rows={2} className={`${fieldClass} resize-none`} />
            ) : (
              <p className="text-sm font-semibold text-[#0F172A]">{form.address}</p>
            )}
          </div>
          <div className="sm:col-span-2">
            <p className="text-[11px] text-[#94A3B8] mb-1 font-semibold">Emergency Address</p>
            {editing ? (
              <textarea value={form.emergAddr} onChange={(e) => setForm({ ...form, emergAddr: e.target.value })} rows={2} className={`${fieldClass} resize-none`} />
            ) : (
              <p className="text-sm font-semibold text-[#0F172A]">{form.emergAddr}</p>
            )}
          </div>
        </div>

        {editing && (
          <div className="px-5 pb-5 flex gap-3">
            <button onClick={handleSave} className="px-5 py-2.5 bg-gradient-to-br from-[#1E3A8A] to-[#3B5FBD] text-white text-sm font-bold rounded-xl hover:opacity-90 transition-opacity shadow-md">
              Save Changes
            </button>
            <button onClick={handleCancel} className="px-5 py-2.5 text-[#64748B] text-sm font-semibold border border-white/60 rounded-xl hover:bg-white/50 transition-colors">
              Cancel
            </button>
          </div>
        )}
      </Card>

      <Card className="overflow-hidden">
        <div className="px-5 py-4 border-b border-white/40">
          <SectionLabel>Family & Guardian</SectionLabel>
        </div>
        <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-5">
          {[
            { label: "Father's Name", value: STUDENT.fatherName },
            { label: "Father's Profession", value: STUDENT.fatherProf },
            { label: "Mother's Name", value: STUDENT.motherName },
            { label: "Mother's Profession", value: STUDENT.motherProf },
            { label: "Guardian's Name", value: STUDENT.guardianName },
            { label: "Guardian's Phone", value: STUDENT.guardianPhone },
          ].map(({ label, value }) => (
            <div key={label}>
              <p className="text-[11px] text-[#94A3B8] mb-0.5 font-semibold">{label}</p>
              <p className="text-sm font-semibold text-[#0F172A]">{value}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ─── Course Feedback ──────────────────────────────────────────────────────────

function FeedbackScreen() {
  const [items, setItems] = useState(FEEDBACK_INIT);
  const [modal, setModal] = useState<number | null>(null);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");

  const pending = items.filter((i) => i.status === "Pending").length;

  function submit() {
    if (modal === null) return;
    setItems(items.map((item, i) => i === modal ? { ...item, status: "Evaluated" } : item));
    setModal(null);
    setRating(0);
    setComment("");
  }

  return (
    <div className="p-4 md:p-8 max-w-4xl">
      <div className="flex items-start justify-between mb-6">
        <PageHeader title="Course Feedback" subtitle={`${STUDENT.ay} · ${STUDENT.semester}`} />
        {pending > 0 && (
          <span className="mt-1 px-3 py-1.5 bg-amber-50/80 backdrop-blur-sm text-amber-700 border border-amber-200 rounded-full text-xs font-bold shrink-0">
            {pending} pending
          </span>
        )}
      </div>

      <StudentBanner />

      <Card className="overflow-hidden">
        <div className="px-5 py-4 border-b border-white/40 flex items-center justify-between">
          <SectionLabel>Feedback Status</SectionLabel>
          <span className="text-[11px] text-[#94A3B8] font-semibold">{items.length} courses</span>
        </div>
        <div className="divide-y divide-white/30">
          {items.map((item, i) => (
            <div key={i} className="flex items-center gap-3 px-5 py-4 hover:bg-white/40 transition-colors">
              <div className="flex-1 min-w-0">
                <p className="text-[11px] font-mono font-bold text-[#94A3B8]">{item.code}</p>
                <p className="text-sm font-semibold text-[#0F172A] truncate mt-0.5">{item.title}</p>
                <p className="text-xs text-[#64748B] mt-0.5 font-medium">{item.teacher}</p>
              </div>
              {item.status === "Evaluated" ? (
                <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold shrink-0">
                  Evaluated
                </span>
              ) : (
                <button
                  onClick={() => setModal(i)}
                  className="px-3 py-1.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200 text-xs font-bold shrink-0 hover:bg-amber-100 transition-colors"
                >
                  Give Feedback
                </button>
              )}
            </div>
          ))}
        </div>
      </Card>

      {modal !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/30 backdrop-blur-md">
          <div className="bg-white/90 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/60 w-full max-w-md">
            <div className="flex items-start justify-between p-5 border-b border-white/40">
              <div>
                <p className="font-bold text-[#0F172A]">{items[modal].title}</p>
                <p className="text-xs text-[#64748B] mt-0.5 font-medium">{items[modal].teacher}</p>
                <p className="text-[11px] font-mono font-bold text-[#94A3B8] mt-0.5">{items[modal].code}</p>
              </div>
              <button onClick={() => setModal(null)} className="text-[#94A3B8] hover:text-[#0F172A] transition-colors">
                <IcoClose />
              </button>
            </div>
            <div className="p-5">
              <p className="text-sm font-bold text-[#0F172A] mb-2">Overall Rating</p>
              <div className="flex gap-0.5 mb-5">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} onClick={() => setRating(n)} className="hover:scale-110 transition-transform">
                    <IcoStar filled={n <= rating} />
                  </button>
                ))}
              </div>
              <label className="block text-sm font-bold text-[#0F172A] mb-1.5">
                Comments <span className="text-[#94A3B8] font-medium">(optional)</span>
              </label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Share your experience with this course..."
                rows={3}
                className="w-full text-sm bg-white/60 border border-white/60 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-[#1E3A8A] focus:ring-2 focus:ring-[#1E3A8A]/10 resize-none transition font-medium"
              />
              <div className="flex gap-3 mt-4">
                <button
                  onClick={submit}
                  disabled={rating === 0}
                  className="flex-1 py-2.5 bg-gradient-to-br from-[#1E3A8A] to-[#3B5FBD] text-white text-sm font-bold rounded-xl hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed transition-opacity shadow-md"
                >
                  Submit Feedback
                </button>
                <button onClick={() => setModal(null)} className="px-4 py-2.5 text-sm font-semibold text-[#64748B] border border-white/60 rounded-xl hover:bg-white/50 transition-colors">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Result ───────────────────────────────────────────────────────────────────

function ResultScreen() {
  const [open, setOpen] = useState<Set<number>>(new Set([4]));

  function toggle(id: number) {
    setOpen((prev) => {
      const next = new Set(prev);
      if (next.has(id)) { next.delete(id); } else { next.add(id); }
      return next;
    });
  }

  return (
    <div className="p-4 md:p-8 max-w-4xl">
      <PageHeader title="Academic Results" subtitle="Complete academic performance record" />
      <StudentBanner />

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
        <StatCard label="CGPA" value={STUDENT.cgpa} sub="out of 4.00" />
        <StatCard label="Semesters" value="4" sub="completed" />
        <StatCard label="Credits" value={String(STUDENT.totalCredits)} sub="earned" />
        <StatCard label="Standing" value="Dean's" sub="List eligible" />
      </div>

      <div className="space-y-2.5">
        {SEMESTERS.map((sem) => {
          const isOpen = open.has(sem.id);
          const totalCr = sem.courses.reduce((s, c) => s + c.cr, 0);
          return (
            <Card key={sem.id} className="overflow-hidden">
              <button
                onClick={() => toggle(sem.id)}
                className="w-full flex items-center justify-between px-5 py-4 hover:bg-white/50 transition-colors text-left"
              >
                <div className="flex items-center gap-3">
                  <span className="font-bold text-base text-[#0F172A] tracking-tight">{sem.label}</span>
                  <span className="text-xs text-[#94A3B8] font-semibold">{sem.period}</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="hidden sm:flex items-center gap-1.5">
                    <span className="text-[11px] text-[#94A3B8] font-semibold">GPA</span>
                    <span className="font-extrabold text-[#0F172A] text-sm">{sem.gpa}</span>
                  </div>
                  <span className="text-[#94A3B8]"><IcoChevronDown open={isOpen} /></span>
                </div>
              </button>

              {isOpen && (
                <div className="border-t border-white/40">
                  <div className="sm:hidden px-5 py-2 bg-white/30 text-xs text-[#64748B] font-semibold">
                    Semester GPA: <span className="font-extrabold text-[#0F172A]">{sem.gpa}</span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-white/30">
                          <th className="text-left px-5 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider">Code</th>
                          <th className="text-left px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider hidden sm:table-cell">Course Title</th>
                          <th className="text-center px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider">Cr.</th>
                          <th className="text-center px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider">Grade</th>
                          <th className="text-center px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider hidden sm:table-cell">Points</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/30">
                        {sem.courses.map((c, i) => (
                          <tr key={i} className="hover:bg-white/30 transition-colors">
                            <td className="px-5 py-3">
                              <span className="text-xs font-mono font-bold text-[#1E3A8A]">{c.code}</span>
                              <p className="sm:hidden text-xs text-[#64748B] mt-0.5 font-medium">{c.title}</p>
                            </td>
                            <td className="px-4 py-3 text-[#0F172A] text-sm font-medium hidden sm:table-cell">{c.title}</td>
                            <td className="px-4 py-3 text-center text-[#64748B] text-sm font-semibold">{c.cr}</td>
                            <td className="px-4 py-3 text-center">
                              <span className={`inline-block px-2.5 py-0.5 rounded-lg text-xs font-bold ${gradeChip(c.grade)}`}>{c.grade}</span>
                            </td>
                            <td className="px-4 py-3 text-center text-[#64748B] text-sm font-semibold hidden sm:table-cell">{c.pts.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="bg-white/30 border-t border-white/40">
                          <td colSpan={2} className="px-5 py-3 text-xs font-bold text-[#64748B]">Total Credits: {totalCr}</td>
                          <td className="px-4 py-3 text-center text-xs font-bold text-[#64748B]">{totalCr}</td>
                          <td className="px-4 py-3 text-center text-xs font-extrabold text-[#0F172A]">GPA {sem.gpa}</td>
                          <td className="hidden sm:table-cell" />
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>

      <p className="mt-4 text-[11px] text-[#94A3B8] italic font-medium">
        Disclaimer: In case of discrepancy in result, the record kept at the Registrar Office shall be considered final.
      </p>
    </div>
  );
}

// ─── Admit Card ───────────────────────────────────────────────────────────────

function AdmitCardScreen() {
  const [downloaded, setDownloaded] = useState(false);

  return (
    <div className="p-4 md:p-8 max-w-4xl">
      <div className="flex items-start justify-between mb-6">
        <PageHeader title="Exam Admit Card" subtitle="Final Examination · December 2024" />
        <button
          onClick={() => setDownloaded(true)}
          className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold bg-gradient-to-br from-[#1E3A8A] to-[#3B5FBD] text-white rounded-xl hover:opacity-90 transition-opacity shadow-md shrink-0"
        >
          <IcoDownload /> Download PDF
        </button>
      </div>

      {downloaded && (
        <div className="mb-4 px-4 py-3 rounded-xl bg-emerald-50/80 backdrop-blur-sm border border-emerald-200 text-emerald-700 text-sm font-semibold">
          Admit card downloaded successfully.
        </div>
      )}

      <Card className="overflow-hidden">
        <div className="bg-gradient-to-br from-[#0B1628] to-[#1E3A8A] px-8 py-7 text-center">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-full border-2 border-white/20 flex items-center justify-center">
              <span className="text-white font-extrabold text-sm">IUT</span>
            </div>
            <div className="text-left">
              <p className="font-extrabold text-white text-lg leading-tight">Islamic University of Technology</p>
              <p className="text-white/40 text-xs mt-0.5 font-medium">Board Bazar, Gazipur-1704, Bangladesh</p>
            </div>
          </div>
          <div className="pt-4 border-t border-white/10">
            <p className="text-white/60 text-[11px] uppercase tracking-[0.15em] font-bold">Examination Admit Card</p>
            <p className="text-white font-bold text-sm mt-0.5">{STUDENT.ay} · {STUDENT.semester}</p>
          </div>
        </div>

        <div className="p-6 flex flex-col sm:flex-row gap-5 border-b border-white/40">
          <div className="flex-1 grid grid-cols-2 gap-4">
            {[
              { label: "Student ID", value: STUDENT.id },
              { label: "Semester", value: `Semester ${STUDENT.semNum}` },
              { label: "Student Name", value: STUDENT.name },
              { label: "Program", value: STUDENT.program },
              { label: "Department", value: STUDENT.dept },
              { label: "Batch", value: STUDENT.batch },
            ].map(({ label, value }) => (
              <div key={label}>
                <p className="text-[11px] text-[#94A3B8] font-semibold">{label}</p>
                <p className="text-sm font-semibold text-[#0F172A] mt-0.5">{value}</p>
              </div>
            ))}
          </div>
          <div className="sm:w-28 flex sm:flex-col items-center gap-3">
            <div className="w-24 h-28 border-2 border-white/60 rounded-xl bg-white/40 backdrop-blur-sm flex items-center justify-center">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#1E3A8A] to-[#3B5FBD] flex items-center justify-center text-white font-extrabold text-lg shadow-md">NA</div>
            </div>
            <p className="text-[10px] text-[#94A3B8] text-center font-semibold">Authorized Photo</p>
          </div>
        </div>

        <div className="p-6">
          <SectionLabel>Examination Schedule</SectionLabel>
          <div className="overflow-x-auto mt-3">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-white/40 rounded-xl">
                  <th className="text-left px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider">Date</th>
                  <th className="text-left px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider hidden sm:table-cell">Time</th>
                  <th className="text-left px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider">Course</th>
                  <th className="text-center px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider">Room</th>
                  <th className="text-center px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider hidden sm:table-cell">Duration</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/30">
                {EXAMS.map((e, i) => (
                  <tr key={i} className="hover:bg-white/30 transition-colors">
                    <td className="px-4 py-3">
                      <p className="font-bold text-[#0F172A] text-xs">{e.date}</p>
                      <p className="text-[#94A3B8] text-xs font-medium">{e.day}</p>
                      <p className="sm:hidden text-[#64748B] text-xs font-medium mt-0.5">{e.time}</p>
                    </td>
                    <td className="px-4 py-3 text-[#64748B] text-xs font-medium hidden sm:table-cell">{e.time}</td>
                    <td className="px-4 py-3">
                      <p className="font-mono font-bold text-[#1E3A8A] text-xs">{e.code}</p>
                      <p className="text-[#0F172A] text-xs mt-0.5 font-medium">{e.title}</p>
                    </td>
                    <td className="px-4 py-3 text-center font-mono font-bold text-[#0F172A] text-xs">{e.room}</td>
                    <td className="px-4 py-3 text-center text-[#64748B] text-xs font-medium hidden sm:table-cell">{e.duration}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="px-6 pb-6 pt-4 border-t border-white/40 flex flex-col sm:flex-row justify-between items-end gap-4">
          <div className="text-xs text-[#94A3B8] font-medium">
            <p>Generated: 15 September 2026</p>
            <p className="mt-1 italic">This admit card must be presented at the examination hall with a valid photo ID.</p>
          </div>
          <div className="text-center shrink-0">
            <div className="w-36 h-px bg-[#0F172A]/20 mb-2" />
            <p className="text-xs text-[#64748B] font-bold">Controller of Examinations</p>
            <p className="text-[10px] text-[#94A3B8] font-medium">Islamic University of Technology</p>
          </div>
        </div>
      </Card>
    </div>
  );
}

// ─── Library ──────────────────────────────────────────────────────────────────

function LibraryScreen() {
  const overdue = LIBRARY_CURRENT.filter((b) => b.daysLeft < 0).length;
  const dueSoon = LIBRARY_CURRENT.filter((b) => b.daysLeft >= 0 && b.daysLeft <= 7).length;

  return (
    <div className="p-4 md:p-8 max-w-4xl">
      <PageHeader title="Library" subtitle="IUT Central Library · Book Management" />

      {/* Summary row */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        <StatCard label="Books Borrowed" value={`${LIBRARY_CURRENT.length}/5`} sub="borrowing limit" />
        <StatCard label="Due Soon" value={String(dueSoon)} sub="within 7 days" />
        <StatCard label="Overdue" value={String(overdue)} sub="return immediately" />
      </div>

      {/* Overdue alert */}
      {overdue > 0 && (
        <div className="flex gap-3 p-4 rounded-2xl bg-red-50/80 backdrop-blur-sm border border-red-200 mb-5">
          <div className="w-0.5 rounded-full bg-red-500 shrink-0" />
          <div>
            <p className="text-xs font-bold text-red-700">Overdue Notice</p>
            <p className="text-xs text-red-600 mt-0.5 font-medium leading-relaxed">
              You have {overdue} overdue book{overdue > 1 ? "s" : ""}. A fine of BDT 5 per day is charged for late returns. Please return them as soon as possible.
            </p>
          </div>
        </div>
      )}

      {/* Currently borrowed */}
      <Card className="overflow-hidden mb-5">
        <div className="px-5 py-4 border-b border-white/40 flex items-center justify-between">
          <SectionLabel>Currently Borrowed</SectionLabel>
          <span className="text-[11px] text-[#94A3B8] font-semibold">{LIBRARY_CURRENT.length} books</span>
        </div>
        <div className="divide-y divide-white/30">
          {LIBRARY_CURRENT.map((book, i) => {
            const st = loanStatus(book.daysLeft);
            return (
              <div key={i} className="px-5 py-4 hover:bg-white/40 transition-colors">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-bold text-[#0F172A] text-sm leading-tight">{book.title}</p>
                      <span className={`shrink-0 inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${st.cls}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${st.dot}`} />
                        {st.label}
                      </span>
                    </div>
                    <p className="text-xs text-[#64748B] font-medium">{book.author}</p>
                    <p className="text-[11px] font-mono text-[#94A3B8] mt-0.5">{book.isbn}</p>
                  </div>
                  <span className="shrink-0 px-2.5 py-1 rounded-lg bg-white/50 border border-white/60 text-[10px] font-bold text-[#64748B] hidden sm:block">
                    {book.category}
                  </span>
                </div>
                <div className="flex items-center gap-4 mt-3 pt-3 border-t border-white/30">
                  <div className="flex items-center gap-1.5">
                    <IcoClock />
                    <span className="text-[11px] text-[#94A3B8] font-semibold">Issued</span>
                    <span className="text-[11px] font-bold text-[#0F172A]">{book.issued}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <IcoClock />
                    <span className="text-[11px] text-[#94A3B8] font-semibold">Due</span>
                    <span className={`text-[11px] font-bold ${book.daysLeft < 0 ? "text-red-600" : book.daysLeft <= 7 ? "text-amber-600" : "text-[#0F172A]"}`}>
                      {book.due}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono font-bold text-[#94A3B8] hidden sm:block ml-auto">{book.id}</span>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Borrowing history */}
      <Card className="overflow-hidden">
        <div className="px-5 py-4 border-b border-white/40 flex items-center justify-between">
          <SectionLabel>Borrowing History</SectionLabel>
          <span className="text-[11px] text-[#94A3B8] font-semibold">{LIBRARY_HISTORY.length} records</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-white/30">
                <th className="text-left px-5 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider">Book</th>
                <th className="text-left px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider hidden md:table-cell">Author</th>
                <th className="text-center px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider hidden sm:table-cell">Issued</th>
                <th className="text-center px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider">Returned</th>
                <th className="text-center px-4 py-2.5 text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/30">
              {LIBRARY_HISTORY.map((book, i) => (
                <tr key={i} className="hover:bg-white/30 transition-colors">
                  <td className="px-5 py-3">
                    <p className="font-semibold text-[#0F172A] text-xs leading-tight">{book.title}</p>
                    <p className="text-[11px] font-mono text-[#94A3B8] mt-0.5">{book.isbn}</p>
                    <p className="md:hidden text-xs text-[#64748B] mt-0.5 font-medium">{book.author}</p>
                  </td>
                  <td className="px-4 py-3 text-xs text-[#64748B] font-medium hidden md:table-cell">{book.author}</td>
                  <td className="px-4 py-3 text-center text-xs text-[#64748B] font-semibold hidden sm:table-cell">{book.issued}</td>
                  <td className="px-4 py-3 text-center text-xs font-semibold text-[#0F172A]">{book.returned}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      book.status === "On Time"
                        ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                        : "bg-red-50 text-red-700 border border-red-200"
                    }`}>
                      {book.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

// ─── Change Password ──────────────────────────────────────────────────────────

function ChangePasswordScreen() {
  const [form, setForm] = useState({ current: "", next: "", confirm: "" });
  const [show, setShow] = useState({ current: false, next: false, confirm: false });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const strength = form.next.length === 0 ? 0 : form.next.length < 8 ? 1 : form.next.length < 12 ? 2 : 3;
  const strengthMeta = [
    { label: "", color: "" },
    { label: "Weak", color: "bg-red-400" },
    { label: "Good", color: "bg-amber-400" },
    { label: "Strong", color: "bg-emerald-500" },
  ][strength];

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    if (!form.current) { setError("Please enter your current password."); return; }
    if (form.next.length < 8) { setError("New password must be at least 8 characters."); return; }
    if (form.next !== form.confirm) { setError("New passwords do not match."); return; }
    setSuccess(true);
    setForm({ current: "", next: "", confirm: "" });
    setTimeout(() => setSuccess(false), 4000);
  }

  const inputClass = "w-full pr-11 text-sm bg-white/60 backdrop-blur-sm border border-white/60 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-[#1E3A8A] focus:bg-white/80 focus:ring-2 focus:ring-[#1E3A8A]/10 transition font-medium";

  return (
    <div className="p-4 md:p-8 max-w-lg">
      <PageHeader title="Change Password" subtitle="Keep your account secure with a strong password." />

      {success && (
        <div className="mb-5 px-4 py-3 rounded-xl bg-emerald-50/80 backdrop-blur-sm border border-emerald-200 text-emerald-700 text-sm font-semibold">
          Password updated successfully. Please use your new password on next login.
        </div>
      )}

      <Card className="p-6">
        <form onSubmit={handleSubmit} className="space-y-5">
          {(["current", "next", "confirm"] as const).map((key) => {
            const labels = { current: "Current Password", next: "New Password", confirm: "Confirm New Password" };
            const placeholders = { current: "Enter current password", next: "Minimum 8 characters", confirm: "Re-enter new password" };
            return (
              <div key={key}>
                <label className="block text-sm font-bold text-[#0F172A] mb-1.5">{labels[key]}</label>
                <div className="relative">
                  <input
                    type={show[key] ? "text" : "password"}
                    value={form[key]}
                    onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                    placeholder={placeholders[key]}
                    className={inputClass}
                  />
                  <button
                    type="button"
                    onClick={() => setShow((s) => ({ ...s, [key]: !s[key] }))}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-[#64748B] transition-colors"
                  >
                    <IcoEye visible={show[key]} />
                  </button>
                </div>

                {key === "next" && form.next.length > 0 && (
                  <div className="mt-2">
                    <div className="flex gap-1 mb-1">
                      {[1, 2, 3].map((n) => (
                        <div key={n} className={`h-1 flex-1 rounded-full transition-all duration-300 ${n <= strength ? strengthMeta.color : "bg-white/50 border border-white/60"}`} />
                      ))}
                    </div>
                    <p className="text-[11px] text-[#94A3B8] font-medium">
                      Strength: <span className="font-bold text-[#0F172A]">{strengthMeta.label}</span>
                    </p>
                  </div>
                )}
              </div>
            );
          })}

          {error && (
            <div className="px-4 py-3 rounded-xl bg-red-50/80 backdrop-blur-sm border border-red-200 text-red-700 text-sm font-semibold">{error}</div>
          )}

          <button
            type="submit"
            className="w-full py-2.5 bg-gradient-to-br from-[#1E3A8A] to-[#3B5FBD] text-white text-sm font-bold rounded-xl hover:opacity-90 transition-opacity shadow-md"
          >
            Update Password
          </button>
        </form>

        <div className="mt-5 pt-5 border-t border-white/40">
          <p className="text-xs text-[#94A3B8] leading-relaxed font-medium">
            Password requirements: minimum 8 characters. Use a mix of letters, numbers, and symbols for a stronger password.
          </p>
        </div>
      </Card>
    </div>
  );
}

// ─── App Root ─────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>("dashboard");
  const [mobileOpen, setMobileOpen] = useState(false);

  function navigate(s: Screen) {
    setScreen(s);
    setMobileOpen(false);
    window.scrollTo(0, 0);
  }

  return (
    <div className="flex h-screen overflow-hidden bg-gradient-to-br from-slate-100 via-blue-50 to-indigo-100">
      {/* Desktop sidebar */}
      <div className="hidden md:flex h-full">
        <Sidebar screen={screen} onNav={navigate} />
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          <div className="w-64 h-full shrink-0">
            <Sidebar screen={screen} onNav={navigate} onClose={() => setMobileOpen(false)} />
          </div>
          <div className="flex-1 bg-black/40 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
        </div>
      )}

      {/* Main area */}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        <TopBar screen={screen} onMenuClick={() => setMobileOpen(true)} />

        <main className="flex-1 overflow-y-auto">
          {screen === "dashboard" && <DashboardScreen onNav={navigate} />}
          {screen === "profile" && <ProfileScreen />}
          {screen === "feedback" && <FeedbackScreen />}
          {screen === "result" && <ResultScreen />}
          {screen === "admit-card" && <AdmitCardScreen />}
          {screen === "library" && <LibraryScreen />}
          {screen === "change-password" && <ChangePasswordScreen />}
        </main>

        <footer className="px-6 py-3 border-t border-white/40 bg-white/50 backdrop-blur-md shrink-0">
          <p className="text-[11px] text-[#94A3B8] font-medium">2026 &copy; Islamic University of Technology &middot; Student Information System</p>
        </footer>
      </div>
    </div>
  );
}
